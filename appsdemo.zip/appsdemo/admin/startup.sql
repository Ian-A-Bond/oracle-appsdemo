SET SERVEROUTPUT ON
prompt Starting the Oracle Database Service &1 for application &2
STARTUP
EXIT