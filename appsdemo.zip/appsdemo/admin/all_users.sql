-- Report users

select name,
       ctime,
       ptime,
       exptime
from   user$;