-- Check current pluggable database connected
--
SHOW CON_NAME