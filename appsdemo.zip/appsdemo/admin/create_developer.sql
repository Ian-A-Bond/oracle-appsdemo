/*
** Copyright (c) 2023 Bond & Pollard Ltd. All rights reserved.  
** NAME   : create_developer.sql
**
** DESCRIPTION
**
**   Create a user with developer privileges for the appsdemo schema. 
**
**
**   Connect as user SYS as SYSDBA to run this script.
**   Create the user
**   Grant privileges to user (tables, views, packages, directories)
**
**------------------------------------------------------------------------------------------------------------------------------
** MODIFICATION HISTORY
**
** Date         Name          Description
**------------------------------------------------------------------------------------------------------------------------------
** 20/04/2023   Ian Bond      Created script
*/

ACCEPT v_user PROMPT "Enter the username to be created"
ACCEPT v_pwd PROMPT "Enter a password for the user"

-- Create the user
DROP USER &v_user;
CREATE USER &v_user IDENTIFIED BY &v_pwd;

GRANT CONNECT TO &v_user;

-- Grant user access to appdsemo tables
--
GRANT DELETE, INSERT, SELECT, UPDATE ON applog TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON appseverity TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON bonus TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON appsdemo.country TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON country_holiday TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON customer TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON demo TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON dept TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON dummy TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON emp TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON importcsv TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON importerror TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON item TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON ord TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON price TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON product TO &v_user;
GRANT DELETE, INSERT, SELECT, UPDATE ON salgrade TO &v_user;

-- Views
GRANT SELECT ON appsdemo.sales to &v_user;

-- Grant user access to UTL_FILE package
GRANT EXECUTE ON sys.utl_file TO &v_user;

-- Grant user access to appsdemo packages
GRANT EXECUTE ON appsdemo.demo_string TO &v_user;
GRANT EXECUTE ON appsdemo.export TO &v_user;
GRANT EXECUTE ON appsdemo.import TO &v_user;
GRANT EXECUTE ON appsdemo.orderrp TO &v_user;
GRANT EXECUTE ON appsdemo.plsql_constants TO &v_user;
GRANT EXECUTE ON appsdemo.util_admin TO &v_user;
GRANT EXECUTE ON appsdemo.util_date TO &v_user;
GRANT EXECUTE ON appsdemo.util_file TO &v_user;
GRANT EXECUTE ON appsdemo.util_numeric TO &v_user;
GRANT EXECUTE ON appsdemo.util_string TO &v_user;

-- Grant user access to Directories
GRANT READ, WRITE ON DIRECTORY data_in TO &v_user;
GRANT READ, WRITE ON DIRECTORY data_in_error TO &v_user;
GRANT READ, WRITE ON DIRECTORY data_in_processed TO &v_user;
GRANT READ, write ON DIRECTORY data_out to &v_user;




