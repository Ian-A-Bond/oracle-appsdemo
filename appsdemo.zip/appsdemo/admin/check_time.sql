-- Check the current system date and time
--
SELECT to_char(sysdate,'DD/MM/RR HH24:MM:SS') FROM dual;