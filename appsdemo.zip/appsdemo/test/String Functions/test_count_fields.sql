SELECT csv_rec, util_string.count_fields(csv_rec,',') FROM importcsv;
SELECT :p_rec, util_string.count_fields(:p_rec,',') FROM dual;