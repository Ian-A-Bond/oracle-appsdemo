-- Test sort_numbers
ACCEPT p_number_list PROMPT "Enter a list of numbers to sort, separated by commas"
SELECT '&p_number_list'
, util_numeric.sort_numbers('&p_number_list', 'A') ascending
, util_numeric.sort_numbers('&p_number_list', 'D') descending
FROM dual;