ACCEPT p_decimal PROMPT "Enter a decimal integer"
ACCEPT p_base PROMPT "Enter the number base to use. Binary is 2 etc."
SELECT &p_decimal "input", &p_base "base"
,util_numeric.dectobase(&p_decimal,&p_base) "base value"
,util_numeric.basetodec(util_numeric.dectobase(&p_decimal,&p_base),&p_base) "decimal value"
FROM dual;

