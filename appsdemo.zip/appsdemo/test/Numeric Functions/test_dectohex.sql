ACCEPT p1 PROMPT "Enter a decimal integer to convert to hexadecimal"
SELECT &p1 "input"
,util_numeric.dectohex(&p1) "hex"
,to_char(&p1,'XXXXXXXX') "check"
,util_numeric.hextodec(util_numeric.dectohex(&p1)) "dec"
FROM dual;

