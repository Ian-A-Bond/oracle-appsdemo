-- Show grants made
--
select * from user_tab_privs_made;