-- Test alphatodec function to convert an alphabetic string to a numeric value
SET SERVEROUTPUT ON SIZE 1000000
ACCEPT p_in_string PROMPT "Please enter a string of alpha characters"

DECLARE 
  v_num_result NUMBER;
  v_string_result VARCHAR2(4000);
BEGIN 
  v_num_result := util_numeric.alphatodec('&p_in_string',26);
  v_string_result := util_numeric.dectoalpha(v_num_result,26);
  dbms_output.put_line('Numeric valus is   : ' ||to_char(v_num_result));
  dbms_output.put_line('String valus is    : ' ||v_string_result);
  dbms_output.put_line('Original message is: ' ||'&p_in_string');
END;