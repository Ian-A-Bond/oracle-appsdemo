ACCEPT p1 PROMPT "Enter a hexadecimal number to convert to decimal"
SELECT '&p1' "input"
,util_numeric.hextodec('&p1') "decimal"
,util_numeric.dectohex(util_numeric.hextodec('&p1')) "hexadecimal"
FROM dual;

