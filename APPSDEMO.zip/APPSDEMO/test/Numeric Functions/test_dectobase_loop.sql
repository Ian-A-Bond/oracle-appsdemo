-- Test the conversion of a series of integers to a specified Base.
--
SET SERVEROUTPUT ON
ACCEPT number_base PROMPT "Enter the number base to use, for example 2 is binary"
DECLARE
  l_base INTEGER;
  l_result VARCHAR2(20);
  l_check INTEGER;
BEGIN
  l_base := &number_base;
  dbms_output.put_line('Convert decimal numbers to base '||to_char(l_base));
  FOR I IN 0 .. 256 LOOP
    l_result := util_numeric.dectobase(I,l_base);
    l_check := util_numeric.basetodec(l_result,l_base);
    dbms_output.put_line('*'||lpad(to_char(I),12)||' = '||lpad(l_result,12)||' Check result= '||to_char(l_check));
  END LOOP;
END;

