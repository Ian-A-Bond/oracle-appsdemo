-- Test creating messaged on the APPLOG
--
SET SERVEROUTPUT ON
ACCEPT v_message  PROMPT "Enter a message to be placed on the log"
ACCEPT v_severity PROMPT "Severity? (I)nfo, (W)arning, (E)rror"
ACCEPT v_mode     PROMPT "Mode (S)creen, (F)ile or (B)oth"
BEGIN
  util_admin.log_message('&v_message','CUSTOM00001-Error Message','TEST_APPLOG.SQL','&v_mode','&v_severity');
END;